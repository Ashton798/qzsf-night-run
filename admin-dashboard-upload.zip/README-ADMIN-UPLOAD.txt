管理员后台 GitHub Desktop 上传说明

1. 解压本 ZIP 到仓库根目录（qzsf-night-run），合并 deploy-vercel 文件夹；不要覆盖或删除其他文件。
2. GitHub Desktop 选择仓库 Ashton798/qzsf-night-run，先拉取 main，然后 Branch > New Branch，名称 feat/admin-dashboard。
3. Changes 中只勾选本 ZIP 带来的 deploy-vercel 文件。不要勾选其他学生端改动、数据、备份或密钥文件。
4. 提交说明：feat: add administrator dashboard。点击 Publish branch / Push origin 推送分支。
5. 创建指向 main 的 Pull Request；预览验证通过前不要合并。

此包包含管理员页面/API/路由依赖和数据库迁移，不含 .env.production.local、Vercel 项目缓存、node_modules 或数据库数据。管理员 API 依赖 001_stage2.sql 与 002_admin.sql。部署前先确认学生端真实报名 API 和生产数据库；勿直接运行迁移或配置生产 DATABASE_URL。
